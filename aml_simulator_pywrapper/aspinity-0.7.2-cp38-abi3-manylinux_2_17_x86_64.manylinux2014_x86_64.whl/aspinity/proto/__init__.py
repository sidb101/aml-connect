try:
    from .asp_log_pb2 import *
    from .asp_pb2 import *
except ModuleNotFoundError as e:
    raise RuntimeError(
        "Missing proto generated files. Try running 'pdm run protoc'. " + str(e)
    )

from google.protobuf.json_format import MessageToJson


def as_json(message):
    return MessageToJson(
        message,
        including_default_value_fields=True,
        preserving_proto_field_name=True,
        sort_keys=True,
    )
