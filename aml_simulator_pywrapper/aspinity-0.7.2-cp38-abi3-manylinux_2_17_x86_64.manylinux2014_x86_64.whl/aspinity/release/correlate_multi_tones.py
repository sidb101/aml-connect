from aspinity.release.correlate_tones import correlate_tones


def correlate_multi_tones(t, reference, response, frequencies_over_time):

    frequency = []
    magnitude = []
    phase = []

    for frequencies in frequencies_over_time:
        f_single, magnitude_single, phase_single, _, _ = correlate_tones(
            t=t, reference=reference, response=response, frequency_over_time=frequencies
        )
        frequency.extend(f_single)
        magnitude.extend(magnitude_single)
        phase.extend(phase_single)
    return frequency, magnitude, phase
