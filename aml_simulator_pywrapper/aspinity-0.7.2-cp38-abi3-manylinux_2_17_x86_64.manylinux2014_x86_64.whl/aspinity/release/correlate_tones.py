import numpy as np


def z2phase(z):
    return np.angle(z)


def z2magnitude(z):
    return np.abs(z)


def correlate_tones(t, reference, response, frequency_over_time):
    frequencies = np.unique(frequency_over_time)
    frequencies = frequencies[np.flatnonzero(frequencies)]

    ref_phase = []
    ref_mag = []
    dut_phase = []
    dut_mag = []

    dc = []
    t_sweep = []

    for frequency in frequencies:
        nD = np.flatnonzero(np.isclose(frequency_over_time, frequency))
        nDMeas = nD[4:-5]

        reference_temp = reference[nDMeas] - np.mean(reference[nDMeas])
        response_temp = response[nDMeas] - np.mean(response[nDMeas])

        real_null = np.cos(2 * np.pi * frequency * t[: len(nDMeas)])
        imag_null = -np.sin(2 * np.pi * frequency * t[: len(nDMeas)])

        real = np.mean(np.multiply(real_null, reference_temp))
        imaginary = np.mean(np.multiply(imag_null, reference_temp))
        z = real + 1j * imaginary
        ref_phase.append(z2phase(z))
        ref_mag.append(z2magnitude(z))

        real = np.mean(np.multiply(real_null, response_temp))
        imaginary = np.mean(np.multiply(imag_null, response_temp))
        z = real + 1j * imaginary
        dut_phase.append(z2phase(z))
        dut_mag.append(z2magnitude(z))

        dc.append(np.median(response[nDMeas]))
        t_sweep.append(np.median(response[nDMeas]))

    magnitude = np.divide(dut_mag, ref_mag)
    phase = np.divide(np.unwrap(np.subtract(dut_phase, ref_phase)), np.pi) * 180
    # wrap up to positive angles
    if np.sum(phase >= 0) == 0:
        phase = np.add(phase, 360)

    return frequencies, magnitude, phase, dc, t_sweep
