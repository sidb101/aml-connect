def display_image(filename, width=1000):
    from IPython.display import Image, display

    display(Image(filename=filename, embed=True, width=width))
