import numpy as np

## Extract coordinates to plot contour/surface plots
def extract_mesh_coordinates(response, x_coordinates, y_coordinates, hold_samples=10):
    output = np.average(response.reshape(-1, hold_samples), axis=1)
    Z = np.reshape(output, (x_coordinates.shape[0],-1))

    return x_coordinates, y_coordinates, Z
