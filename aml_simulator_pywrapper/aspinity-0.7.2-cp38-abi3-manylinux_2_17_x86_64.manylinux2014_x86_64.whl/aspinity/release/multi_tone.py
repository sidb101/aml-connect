import numpy as np


def multi_tone(
    frequencies=None,
    amplitudes=None,
    dc_offset=0.0,
    settle_time=0.1,
    oversample_ratio=10.0,
    averaging_cycles=20,
):

    if frequencies is None:
        frequencies = np.logspace(1, 4, 30)
    if amplitudes is None:
        amplitudes = 0.003 + np.zeros_like(frequencies)

    rounding_resolution = 100
    sample_rate = oversample_ratio * 2 * np.max(frequencies)
    sample_rate = np.ceil(sample_rate / rounding_resolution) * rounding_resolution
    sample_rate = np.min([sample_rate, 100e3])

    averaging_cycles_duration = averaging_cycles / np.min(frequencies)
    t = np.arange(0, averaging_cycles_duration + (1 / sample_rate), (1 / sample_rate))
    settle_zeros = [0] * int(np.ceil(settle_time * sample_rate))
    all_tones = []
    frequencies_over_time = []
    for i in range(len(frequencies)):
        single_tone = amplitudes[i] * np.sin(2 * np.pi * frequencies[i] * t)
        all_tones.append(np.concatenate([settle_zeros, single_tone]))
        frequency_over_time = [frequencies[i]] * len(t)
        frequencies_over_time.append(
            np.concatenate([settle_zeros, frequency_over_time])
        )

    _multi_tone = np.sum(all_tones, axis=0) + dc_offset
    t = np.arange(len(_multi_tone)) / sample_rate

    return t, _multi_tone, frequencies_over_time
