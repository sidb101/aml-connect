import numpy as np

def parameters_to_analog(weights, biases):

    weights.append(np.eye(np.array(weights[-1]).shape[0]))
    biases.append(np.zeros(np.array(biases[-1]).shape[0]).reshape(-1,1))

    activation_scale = 0.8 / (2 * 0.0259)
    weights[0] = weights[0] / activation_scale
    weights[-1] = np.array(weights[-1]) / 2
    biases = [np.array(b) / activation_scale for b in biases]

    return weights, biases
