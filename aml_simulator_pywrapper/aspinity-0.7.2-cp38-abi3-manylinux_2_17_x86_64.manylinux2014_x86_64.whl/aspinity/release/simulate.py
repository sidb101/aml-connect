import numpy as np
from aspinity.native import simulate_network


def simulate(models, t, s):
    wav_scale = 5.0
    sample_rate = int((1 / np.diff(t[:2]))[0])
    s = s / wav_scale
    if len(s.shape) == 1:
        s = np.reshape(s, (-1, s.shape[0]))

    input_matrix = np.transpose(s)

    return {
        net: np.array(node)
        for net, node in simulate_network(
            models, input_matrix * wav_scale, sample_rate
        ).items()
    }
