import numpy as np

def sweep_mesh(min_val=-0.1, max_val=-0.1, resolution=0.001, hold_samples=10):

    h = resolution
    x1_min, x1_max = min_val, max_val
    x2_min, x2_max = min_val, max_val
    hold_samples = hold_samples

    x1_range = np.arange(x1_min, x1_max, h)
    x2_range = np.arange(x2_min, x2_max, h)
    x_coordinates, y_coordinates = np.meshgrid(x1_range,
                    x2_range)

    flattened_xy = np.reshape(np.stack((x_coordinates.ravel(), y_coordinates.ravel()), axis=1),(-1, 2)).T

    ## Each xy coornidate in the grid is repeated "hold_samples" number of times
    mesh_input_sweep = np.repeat(flattened_xy, hold_samples, axis=1)

    return mesh_input_sweep, x_coordinates, y_coordinates
