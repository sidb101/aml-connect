import numpy as np


def swept_sines(
    start_frequency=100.0,
    stop_frequency=10.0e3,
    steps=30,
    amplitude=0.1,
    dc_offset=0,
    settle_time=0.1,
    oversample_ratio=10,
    averaging_cycles=20,
    minimum_duration_per_frequency=0,
):
    frequencies = np.logspace(
        np.log10(start_frequency), np.log10(stop_frequency), steps
    )

    rounding_resolution = 100
    sample_rate = oversample_ratio * 2 * np.max(frequencies)
    sample_rate = np.ceil(sample_rate / rounding_resolution) * rounding_resolution
    sample_rate = int(np.minimum(sample_rate, 100e3))
    period = 1 / sample_rate

    frequency_over_time = []
    out = []

    for frequency in frequencies:
        ## (AC) Reduce number of cycles needed for low frequencies, increase at high
        if frequency < 50:
            averaging_cycles = 5
        elif frequency >= 50 and frequency < 100:
            averaging_cycles = 10
        elif frequency >= 100 and frequency < 1000:
            averaging_cycles = 20
        else:
            averaging_cycles = 50
        averaging_cycles_duration = averaging_cycles / frequency
        tone_duration = np.maximum(
            averaging_cycles_duration, minimum_duration_per_frequency
        )
        t = np.arange(0, tone_duration, period)
        out.extend(list(np.sin(2 * np.pi * frequency * t)))
        frequency_over_time.extend(0 * t + frequency)

    settle_zeros = np.zeros(int(settle_time * sample_rate))
    out = np.concatenate((settle_zeros, np.array(out)))
    frequency_over_time = np.concatenate((settle_zeros, np.array(frequency_over_time)))
    out = amplitude * out + dc_offset
    t = np.arange(0, len(out)) / sample_rate
    return t, out, frequency_over_time
